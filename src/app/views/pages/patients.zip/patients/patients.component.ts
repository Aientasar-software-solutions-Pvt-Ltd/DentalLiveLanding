import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patients',
  templateUrl: './patients.component.html',
  styles: [
  ]
})
export class PatientsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
