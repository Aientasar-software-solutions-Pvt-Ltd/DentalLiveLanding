export const environment = {
  production: true,
  name:"",
  decryptKey: 'DentalLive@2021',
  apiBaseurl:"https://hx4mf30vd7.execute-api.us-west-2.amazonaws.com/development/"
};
