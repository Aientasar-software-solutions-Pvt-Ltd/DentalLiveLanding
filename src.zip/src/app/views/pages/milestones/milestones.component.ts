import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-milestones',
  templateUrl: './milestones.component.html',
  styles: [
  ]
})
export class MilestonesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
