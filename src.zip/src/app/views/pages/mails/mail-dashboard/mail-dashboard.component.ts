import { Component, OnInit } from '@angular/core';
import * as swal from 'sweetalert';

@Component({
  selector: 'app-mail-dashboard',
  templateUrl: './mail-dashboard.component.html',
  styleUrls: ['./mail-dashboard.component.css']
})
export class MailDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
