import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-files',
  templateUrl: './files.component.html',
  styles: [
  ]
})
export class FilesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
