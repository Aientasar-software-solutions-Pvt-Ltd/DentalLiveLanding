import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cases',
  templateUrl: './cases.component.html',
  styles: [
  ]
})
export class CasesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
