import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-colleagues',
  templateUrl: './colleagues.component.html',
  styles: [
  ]
})
export class ColleaguesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
