import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invitations',
  templateUrl: './invitations.component.html',
  styles: [
  ]
})
export class InvitationsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
