import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-work-orders',
  templateUrl: './work-orders.component.html',
  styles: [ ]
})
export class WorkOrdersComponent implements OnInit {

	constructor() { }

	ngOnInit(): void {}

}
